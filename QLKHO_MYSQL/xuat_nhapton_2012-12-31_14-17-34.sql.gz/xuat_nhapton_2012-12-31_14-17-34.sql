#SXD20|20008|50516|50308|2012.12.31 14:17:34|xuat_nhapton|utf8|30|310|
#TA bophan`4`16384|chitiethdn`12`16384|chitiethdx`15`16384|chitiethoadontra`0`16384|chucnang`25`16384|congnokh`0`16384|congnoncc`0`16384|donvitinh`1`16384|hoadonnhap`8`16384|hoadontra`0`16384|hoadonxuat`9`16384|khachhang`3`16384|kho`2`16384|khuvuc`1`16384|log`3`16384|mathang`4`16384|nhacungcap`1`16384|nhanvien`4`16384|nhomhang`1`16384|phankho`8`16384|phanquyen`100`16384|phieuchi`3`16384|phieuthu`12`16384|thongtinct`1`16384|thue`1`16384|tonkho`53`16384|trachitiethdn`12`16384|trachitiethdx`13`16384|trahoadonnhap`7`16384|trahoadonxuat`7`16384
#PR myProc
#EOH

#	TC`bophan`utf8_unicode_ci	;
CREATE TABLE `bophan` (
  `MABP` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `TENBOPHAN` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TINHTRANG` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`MABP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`bophan`utf8_unicode_ci	;
INSERT INTO `bophan` VALUES 
('MABP00001','Mua Hàng','True'),
('MABP00002','Bán hàng','True'),
('MABP00003','Mua bán hàng','True'),
('MABP00004','Quản lý hệ thống','True')	;
#	TC`chitiethdn`utf8_unicode_ci	;
CREATE TABLE `chitiethdn` (
  `ID` int(11) NOT NULL,
  `MAHDN` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MAMH` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `SOLUONGNHAP` int(11) DEFAULT NULL,
  `GIANHAP` bigint(20) DEFAULT NULL,
  `TINHTRANG` bit(1) DEFAULT NULL,
  PRIMARY KEY (`ID`,`MAHDN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`chitiethdn`utf8_unicode_ci	;
INSERT INTO `chitiethdn` VALUES 
(1,'MAHDN00001','MH00001',9,99,'1'),
(1,'MAHDN00002','MH00001',3,99,'1'),
(1,'MAHDN00003','MH00001',5,99,'1'),
(1,'MAHDN00004','MH00001',2,99,'1'),
(1,'MAHDN00005','MH00001',5,99,'1'),
(1,'MAHDN00006','MH00001',2,99,'1'),
(1,'MAHDN00007','MH00001',3,99,'1'),
(1,'MAHDN00008','MH00001',0,99,'0'),
(2,'MAHDN00002','MH00003',3,89,'1'),
(2,'MAHDN00007','MH00003',3,89,'1'),
(3,'MAHDN00002','MH00002',3,99,'1'),
(3,'MAHDN00007','MH00002',3,99,'1')	;
#	TC`chitiethdx`utf8_unicode_ci	;
CREATE TABLE `chitiethdx` (
  `ID` int(11) NOT NULL,
  `MAHDX` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MAMH` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `SOLUONGXUAT` int(11) DEFAULT NULL,
  `GIATIEN` bigint(20) DEFAULT NULL,
  `TINHTRANG` bit(1) DEFAULT NULL,
  PRIMARY KEY (`ID`,`MAHDX`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`chitiethdx`utf8_unicode_ci	;
INSERT INTO `chitiethdx` VALUES 
(1,'MAHDX00014','MH00001',6,99,'1'),
(1,'MAHDX00015','MH00001',3,99,'1'),
(1,'MAHDX00016','MH00001',2,99,'1'),
(1,'MAHDX00017','MH00001',1,99,'1'),
(1,'MAHDX00018','MH00001',2,99,'1'),
(1,'MAHDX00019','MH00001',3,99,'1'),
(1,'MAHDX00020','MH00001',2,99,'1'),
(1,'MAHDX00021','MH00001',2,99,'0'),
(1,'MAHDX00022','MH00002',0,99,'0'),
(2,'MAHDX00014','MH00002',6,99,'1'),
(2,'MAHDX00015','MH00002',2,99,'1'),
(2,'MAHDX00020','MH00002',2,99,'1'),
(3,'MAHDX00014','MH00003',6,89,'1'),
(3,'MAHDX00015','MH00003',2,89,'1'),
(4,'MAHDX00015','MH00001',1,99,'0')	;
#	TC`chitiethoadontra`utf8_unicode_ci	;
CREATE TABLE `chitiethoadontra` (
  `MAHDT` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MAMH` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `SOLUONGTRA` int(11) DEFAULT NULL,
  `TINHTRANG` bit(1) DEFAULT NULL,
  PRIMARY KEY (`MAHDT`,`MAMH`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`chucnang`utf8_unicode_ci	;
CREATE TABLE `chucnang` (
  `MACN` int(15) NOT NULL AUTO_INCREMENT,
  `CHUCNANG` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`MACN`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`chucnang`utf8_unicode_ci	;
INSERT INTO `chucnang` VALUES 
(1,'NHẬP HÀNG'),
(2,'XUẤT HÀNG'),
(3,'TỒN HÀNG HÓA'),
(4,'TRẢ HÀNG CHO NHÀ CUNG CẤP'),
(5,'KHÁCH TRẢ HÀNG'),
(6,'THU TIỀN'),
(7,'TRẢ TIỀN'),
(8,'TỔNG HỢP'),
(9,'DOANH THU'),
(10,'TỒN KHO'),
(11,'KHÁCH HÀNG'),
(12,'NHÀ CUNG CẤP'),
(13,'KHU VỰC'),
(14,'KHO'),
(15,'NHÓM HÀNG'),
(16,'HÀNG HÓA'),
(17,'ĐƠN VỊ TÍNH'),
(18,'NHÂN VIÊN'),
(19,'BỘ PHẬN'),
(20,'THUẾ'),
(21,'SAO LƯU'),
(22,'PHỤC HỒI'),
(23,'PHÂN QUYỀN'),
(24,'ĐỔI MẬT KHẨU'),
(25,'THÔNG TIN')	;
#	TC`congnokh`utf8_unicode_ci	;
CREATE TABLE `congnokh` (
  `MAKH` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `TONGTIENTRA` bigint(20) DEFAULT NULL,
  `TONGTIENDATRA` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`congnoncc`utf8_unicode_ci	;
CREATE TABLE `congnoncc` (
  `MANCC` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `TONGTIENTRA` bigint(20) DEFAULT NULL,
  `TONGTIENDATRA` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`donvitinh`utf8_unicode_ci	;
CREATE TABLE `donvitinh` (
  `MADVT` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `DONVITINH` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`MADVT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`donvitinh`utf8_unicode_ci	;
INSERT INTO `donvitinh` VALUES 
('DVT00001','Chai')	;
#	TC`hoadonnhap`utf8_unicode_ci	;
CREATE TABLE `hoadonnhap` (
  `MAHDN` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MANCC` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MANV` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MAKHO` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `NGAYNHAP` datetime DEFAULT NULL,
  `TIENPHAITRA` bigint(20) DEFAULT NULL,
  `TIENDATRA` bigint(20) DEFAULT NULL,
  `GHICHU` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TINHTRANG` bit(1) DEFAULT NULL,
  PRIMARY KEY (`MAHDN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`hoadonnhap`utf8_unicode_ci	;
INSERT INTO `hoadonnhap` VALUES 
('MAHDN00001','MANCC00001','MANV00001','MAKHO00001','2012-12-21 00:00:00',2583,0,'','1'),
('MAHDN00002','MANCC00001','MANV00001','MAKHO00001','2012-12-21 00:00:00',861,0,'','1'),
('MAHDN00003','MANCC00001','MANV00001','MAKHO00001','2012-12-22 00:00:00',495,0,'','1'),
('MAHDN00004','MANCC00001','MANV00001','MAKHO00001','2012-12-23 00:00:00',198,0,'','1'),
('MAHDN00005','MANCC00001','MANV00001','MAKHO00001','2012-12-25 00:00:00',495,0,'','1'),
('MAHDN00006','MANCC00001','MANV00001','MAKHO00001','2012-12-25 00:00:00',198,0,'','1'),
('MAHDN00007','MANCC00001','MANV00001','MAKHO00001','2012-12-25 00:00:00',861,0,'GHI CHÚ','1'),
('MAHDN00008','MANCC00001','MANV00001','MAKHO00001','2012-12-29 00:00:00',0,0,'','0')	;
#	TC`hoadontra`utf8_unicode_ci	;
CREATE TABLE `hoadontra` (
  `MAHDT` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MANCC` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MAHDN` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `NGAYTRA` datetime DEFAULT NULL,
  `GHICHU` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TINHTRANG` bit(1) DEFAULT NULL,
  PRIMARY KEY (`MAHDT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`hoadonxuat`utf8_unicode_ci	;
CREATE TABLE `hoadonxuat` (
  `MAHDX` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MAKH` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MANV` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MAKHO` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `NGAYXUAT` datetime DEFAULT NULL,
  `TIENPHAITRA` bigint(20) DEFAULT NULL,
  `TIENDATRA` bigint(20) DEFAULT NULL,
  `GHICHU` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TINHTRANG` bit(1) DEFAULT NULL,
  PRIMARY KEY (`MAHDX`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`hoadonxuat`utf8_unicode_ci	;
INSERT INTO `hoadonxuat` VALUES 
('MAHDX00014','KH00001','MANV00001','MAKHO00001','2012-12-21 00:00:00',1722,0,'','1'),
('MAHDX00015','KH00001','MANV00001','MAKHO00001','2012-12-21 00:00:00',772,0,'','1'),
('MAHDX00016','KH00001','MANV00001','MAKHO00001','2012-12-22 00:00:00',198,0,'','1'),
('MAHDX00017','KH00001','MANV00001','MAKHO00001','2012-12-23 00:00:00',99,0,'','1'),
('MAHDX00018','KH00001','MANV00001','MAKHO00001','2012-12-25 00:00:00',198,0,'','1'),
('MAHDX00019','KH00001','MANV00001','MAKHO00001','2012-12-25 00:00:00',297,0,'','1'),
('MAHDX00020','KH00001','MANV00001','MAKHO00001','2012-12-25 00:00:00',574,574,'ghi chú','1'),
('MAHDX00021','KH00003','MANV00001','MAKHO00001','2012-12-26 00:00:00',198,0,'','0'),
('MAHDX00022','KH00001','MANV00001','MAKHO00001','2012-12-29 00:00:00',0,0,'','0')	;
#	TC`khachhang`utf8_unicode_ci	;
CREATE TABLE `khachhang` (
  `MAKH` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MAKV` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `TENKH` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `SOTAIKHOAN` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NGANHANG` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MASOTHUE` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DIACHI` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SDT` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FAX` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WEBSITE` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `YAHOO` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SKYPE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TINHTRANG` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`MAKH`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`khachhang`utf8_unicode_ci	;
INSERT INTO `khachhang` VALUES 
('KH00001','MAKV00001','Phạm Duy Tiên','956','vcb','45450','Vũng tàu','0935199144','354350','64','dfdert','tryfdhg','True'),
('KH00003','MAKV00001','Tuấn Dũng','','','','Q3,TPHCM','0935199144','','','','','True'),
('KH00004','MAKV00001','lê thị kim huệ','998856','viet com bank','989987675','19/65/56 tân chánh hiệp 05 q12','907890089','988765456','datthanh.com','datthanh39','datthanh39','True')	;
#	TC`kho`utf8_unicode_ci	;
CREATE TABLE `kho` (
  `MAKHO` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MANV` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `TENKHO` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DIACHI` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SDTB` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DTDD` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NGUOILH` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FAX` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GHICHU` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TINHTRANG` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`MAKHO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`kho`utf8_unicode_ci	;
INSERT INTO `kho` VALUES 
('MAKHO00001','MANV00001','Kho thuốc','32/144Nguyễn Trãi,Q5,TPHCM','08-3123456','0908888888','đạt thành','098857 356','','True'),
('MAKHO00002','MANV00001','kho cám','','','','','','','True')	;
#	TC`khuvuc`utf8_unicode_ci	;
CREATE TABLE `khuvuc` (
  `MAKV` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `TENKV` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GHICHU` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TINHTRANG` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`MAKV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`khuvuc`utf8_unicode_ci	;
INSERT INTO `khuvuc` VALUES 
('MAKV00001','Hà Nội','','True')	;
#	TC`log`utf8_unicode_ci	;
CREATE TABLE `log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MAHD` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MAMH` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `SOLUONG` int(11) NOT NULL,
  `LOG` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `LYDO` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`log`utf8_unicode_ci	;
INSERT INTO `log` VALUES 
(1,'MAHDN00001','MH00003',1,'THEM',''),
(2,'MAHDN00001','MH00003',9,'DELETE',''),
(3,'MAHDN00001','MH00002',9,'DELETE','')	;
#	TC`mathang`utf8_unicode_ci	;
CREATE TABLE `mathang` (
  `MAMH` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MATH` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MANH` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MAKHO` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TENMH` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MADVT` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SOLUONGMH` int(11) DEFAULT NULL,
  `HANSUDUNG` datetime DEFAULT '2070-12-31 00:00:00',
  `GIAMUA` bigint(20) DEFAULT NULL,
  `GIABAN` bigint(20) DEFAULT NULL,
  `MOTA` text COLLATE utf8_unicode_ci,
  `TINHTRANG` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`MAMH`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`mathang`utf8_unicode_ci	;
INSERT INTO `mathang` VALUES 
('MH00001','TH00001','NH00001','MAKHO00001','vắc xin','DVT00001',113,'0000-00-00 00:00:00',89,99,'','True'),
('MH00002','TH00001','NH00001','MAKHO00001','kháng sinh','DVT00001',97,'0000-00-00 00:00:00',89,99,'','True'),
('MH00003','TH00001','NH00001','MAKHO00001','tăng trọng','DVT00001',102,'0000-00-00 00:00:00',87,89,'','True'),
('MH00004','TH00001','NH00001','MAKHO00002','MAT HANG MOI','DVT00001',110,'0000-00-00 00:00:00',87,89,'','True')	;
#	TC`nhacungcap`utf8_unicode_ci	;
CREATE TABLE `nhacungcap` (
  `MANCC` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MAKV` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `TENNCC` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DIACHI` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MASOTHUE` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SOTAIKHOAN` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NGANHANG` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SDT` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FAX` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WEBSITE` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TINHTRANG` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`MANCC`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`nhacungcap`utf8_unicode_ci	;
INSERT INTO `nhacungcap` VALUES 
('MANCC00001','MAKV00001','Bốt Cám','43 Nguyễn thông,TPHCM','123456','19001789','Việt Com Bank','0935399144','datthanh39','08-345678','www.bdt.com','True')	;
#	TC`nhanvien`utf8_unicode_ci	;
CREATE TABLE `nhanvien` (
  `MANV` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MABP` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USERNAME` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PASSWORD` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CHUCVU` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TENNV` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DIACHI` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NGAYSINH` datetime DEFAULT NULL,
  `SCMND` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SDT` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TINHTRANG` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`MANV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`nhanvien`utf8_unicode_ci	;
INSERT INTO `nhanvien` VALUES 
('MANV00001','MABP00004','admin','123456',\N,'Ðoàn Ngọc Anh','Hoàn Kiếm,Hà nội','2012-12-20 00:00:00','271723434','0906666666','True'),
('MANV00002','MABP00001','manhcuong','123456',\N,' Nguyễn Mạnh Cường ','Hoàn Kiếm,Hà nội','2012-12-20 00:00:00','','0907777777','True'),
('MANV00003','MABP00001','tuandung','123456',\N,' Trần Tuấn Dũng','Hoàn Kiếm,Hà nội','2012-12-20 00:00:00','','0906666666','True'),
('MANV00004','MABP00001','duytien','123456',\N,'Phạm Duy Tiên','Hoàn Kiếm,Hà nội','2012-12-20 00:00:00','','0906666666','True')	;
#	TC`nhomhang`utf8_unicode_ci	;
CREATE TABLE `nhomhang` (
  `MANH` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `TENNHOMHANG` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GHICHU` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`MANH`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`nhomhang`utf8_unicode_ci	;
INSERT INTO `nhomhang` VALUES 
('NH00001','Nước Hoa','Thom nhu múi mít')	;
#	TC`phankho`utf8_unicode_ci	;
CREATE TABLE `phankho` (
  `MABP` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MAKHO` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `QUANLY` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`MABP`,`MAKHO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`phankho`utf8_unicode_ci	;
INSERT INTO `phankho` VALUES 
('MABP00001','MAKHO00001',1),
('MABP00001','MAKHO00002',1),
('MABP00002','MAKHO00001',0),
('MABP00002','MAKHO00002',0),
('MABP00003','MAKHO00001',0),
('MABP00003','MAKHO00002',0),
('MABP00004','MAKHO00001',1),
('MABP00004','MAKHO00002',1)	;
#	TC`phanquyen`utf8_unicode_ci	;
CREATE TABLE `phanquyen` (
  `MABP` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MACN` int(11) NOT NULL,
  `TATCA` tinyint(1) NOT NULL DEFAULT '1',
  `TRUYCAP` tinyint(1) NOT NULL DEFAULT '1',
  `THEM` tinyint(1) NOT NULL DEFAULT '1',
  `XOA` int(11) NOT NULL DEFAULT '1',
  `SUA` int(11) NOT NULL DEFAULT '1',
  `IN` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`MABP`,`MACN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`phanquyen`utf8_unicode_ci	;
INSERT INTO `phanquyen` VALUES 
('MABP00001',1,1,1,1,1,1,1),
('MABP00001',2,1,1,1,1,1,1),
('MABP00001',3,1,1,1,1,1,1),
('MABP00001',4,1,1,1,1,1,1),
('MABP00001',5,1,1,1,1,1,1),
('MABP00001',6,1,1,1,1,1,1),
('MABP00001',7,1,1,1,1,1,1),
('MABP00001',8,1,1,1,1,1,1),
('MABP00001',9,1,1,1,1,1,1),
('MABP00001',10,1,1,1,1,1,1),
('MABP00001',11,1,1,1,1,1,1),
('MABP00001',12,1,1,1,1,1,1),
('MABP00001',13,1,1,1,1,1,1),
('MABP00001',14,1,1,1,1,1,1),
('MABP00001',15,1,1,1,1,1,1),
('MABP00001',16,1,1,1,1,1,1),
('MABP00001',17,1,1,1,1,1,1),
('MABP00001',18,1,1,1,1,1,1),
('MABP00001',19,1,1,1,1,1,1),
('MABP00001',20,1,1,1,1,1,1),
('MABP00001',21,1,1,1,1,1,1),
('MABP00001',22,1,1,1,1,1,1),
('MABP00001',23,1,1,1,1,1,1),
('MABP00001',24,1,1,1,1,1,1),
('MABP00001',25,1,1,1,1,1,1),
('MABP00002',1,1,1,1,1,1,1),
('MABP00002',2,1,1,1,1,1,1),
('MABP00002',3,1,1,1,1,1,1),
('MABP00002',4,1,1,1,1,1,1),
('MABP00002',5,1,1,1,1,1,1),
('MABP00002',6,1,1,1,1,1,1),
('MABP00002',7,1,1,1,1,1,1),
('MABP00002',8,1,1,1,1,1,1),
('MABP00002',9,1,1,1,1,1,1),
('MABP00002',10,1,1,1,1,1,1),
('MABP00002',11,1,1,1,1,1,1),
('MABP00002',12,1,1,1,1,1,1),
('MABP00002',13,1,1,1,1,1,1),
('MABP00002',14,1,1,1,1,1,1),
('MABP00002',15,1,1,1,1,1,1),
('MABP00002',16,1,1,1,1,1,1),
('MABP00002',17,1,1,1,1,1,1),
('MABP00002',18,1,1,1,1,1,1),
('MABP00002',19,1,1,1,1,1,1),
('MABP00002',20,1,1,1,1,1,1),
('MABP00002',21,1,1,1,1,1,1),
('MABP00002',22,1,1,1,1,1,1),
('MABP00002',23,1,1,1,1,1,1),
('MABP00002',24,1,1,1,1,1,1),
('MABP00002',25,1,1,1,1,1,1),
('MABP00003',1,1,1,1,1,1,1),
('MABP00003',2,1,1,1,1,1,1),
('MABP00003',3,1,1,1,1,1,1),
('MABP00003',4,1,1,1,1,1,1),
('MABP00003',5,1,1,1,1,1,1),
('MABP00003',6,1,1,1,1,1,1),
('MABP00003',7,1,1,1,1,1,1),
('MABP00003',8,1,1,1,1,1,1),
('MABP00003',9,1,1,1,1,1,1),
('MABP00003',10,1,1,1,1,1,1),
('MABP00003',11,1,1,1,1,1,1),
('MABP00003',12,1,1,1,1,1,1),
('MABP00003',13,1,1,1,1,1,1),
('MABP00003',14,1,1,1,1,1,1),
('MABP00003',15,1,1,1,1,1,1),
('MABP00003',16,1,1,1,1,1,1),
('MABP00003',17,1,1,1,1,1,1),
('MABP00003',18,1,1,1,1,1,1),
('MABP00003',19,1,1,1,1,1,1),
('MABP00003',20,1,1,1,1,1,1),
('MABP00003',21,1,1,1,1,1,1),
('MABP00003',22,1,1,1,1,1,1),
('MABP00003',23,1,1,1,1,1,1),
('MABP00003',24,1,1,1,1,1,1),
('MABP00003',25,1,1,1,1,1,1),
('MABP00004',1,1,1,1,1,1,1),
('MABP00004',2,1,1,1,1,1,1),
('MABP00004',3,1,1,1,1,1,1),
('MABP00004',4,1,1,1,1,1,1),
('MABP00004',5,1,1,1,1,1,1),
('MABP00004',6,1,1,1,1,1,1),
('MABP00004',7,1,1,1,1,1,1),
('MABP00004',8,1,1,1,1,1,1),
('MABP00004',9,1,1,1,1,1,1),
('MABP00004',10,1,1,1,1,1,1),
('MABP00004',11,1,1,1,1,1,1),
('MABP00004',12,1,1,1,1,1,1),
('MABP00004',13,1,1,1,1,1,1),
('MABP00004',14,1,1,1,1,1,1),
('MABP00004',15,1,1,1,1,1,1),
('MABP00004',16,1,1,1,1,1,1),
('MABP00004',17,1,1,1,1,1,1),
('MABP00004',18,1,1,1,1,1,1),
('MABP00004',19,1,1,1,1,1,1),
('MABP00004',20,1,1,1,1,1,1),
('MABP00004',21,1,1,1,1,1,1),
('MABP00004',22,1,1,1,1,1,1),
('MABP00004',23,1,1,1,1,1,1),
('MABP00004',24,1,1,1,1,1,1),
('MABP00004',25,1,1,1,1,1,1)	;
#	TC`phieuchi`utf8_unicode_ci	;
CREATE TABLE `phieuchi` (
  `MaPC` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MaNV` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MaHDN` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NgayChi` datetime DEFAULT NULL,
  `SoTienDaTra_PC` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`MaPC`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`phieuchi`utf8_unicode_ci	;
INSERT INTO `phieuchi` VALUES 
('PC00001','MANV00001','MAHDN00004','2012-12-17 00:00:00',90000),
('PC00002','MANV00001','MAHDN00004','2012-12-17 00:00:00',5000),
('PC00003','MANV00001','MAHDN00004','2012-12-17 00:00:00',10000)	;
#	TC`phieuthu`utf8_unicode_ci	;
CREATE TABLE `phieuthu` (
  `MaPT` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MaNV` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mahdx` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NgayThu` datetime DEFAULT NULL,
  `SoTienTra_PT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`MaPT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`phieuthu`utf8_unicode_ci	;
INSERT INTO `phieuthu` VALUES 
('PT00001','MANV00001','MAHDX00007','2012-12-16 00:00:00',630),
('PT00002','MANV00001','MAHDX00008','2012-12-16 00:00:00',315000),
('PT00003','MANV00001','MAHDX00005','2012-12-16 00:00:00',420000),
('PT00004','MANV00001','MAHDX00006','2012-12-17 00:00:00',210000),
('PT00005','MANV00001','MAHDX00007','2012-12-17 00:00:00',629370),
('PT00006','MANV00001','MAHDX00007','2012-12-17 00:00:00',2),
('PT00007','MANV00001','MAHDX00007','2012-12-17 00:00:00',1),
('PT00008','MANV00001','MAHDX00009','2012-12-17 00:00:00',210002),
('PT00009','MANV00001','MAHDX00001','2012-12-18 00:00:00',1490000),
('PT00010','MANV00001','MAHDX00003','2012-12-18 00:00:00',524877),
('PT00011','Ðoàn Ngọc Anh','MAHDX00020','2012-12-29 00:00:00',57),
('PT00012','MANV00001','MAHDX00020','2012-12-29 00:00:00',517)	;
#	TC`thongtinct`utf8_unicode_ci	;
CREATE TABLE `thongtinct` (
  `MACT` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `TENCT` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DIACHI` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SDT` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MOBILE` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FAX` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOGO` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MASOTHUE` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WEBSITE` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`MACT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`thongtinct`utf8_unicode_ci	;
INSERT INTO `thongtinct` VALUES 
('1','nguyeenx dat thanh','quan 12 tp ho chi minh','09230293','02392093','datthanh39','39283923','','98978678','www.Infoworldschool.com')	;
#	TC`thue`utf8_unicode_ci	;
CREATE TABLE `thue` (
  `MATH` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `SOTHUE` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`MATH`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`thue`utf8_unicode_ci	;
INSERT INTO `thue` VALUES 
('TH00001',0)	;
#	TC`tonkho`utf8_unicode_ci	;
CREATE TABLE `tonkho` (
  `STT` int(11) NOT NULL,
  `ID` int(11) NOT NULL,
  `MAHD` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MAMH` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `NGAY` datetime NOT NULL,
  `TONDAU` int(11) DEFAULT '0',
  `NHAP` int(11) DEFAULT '0',
  `XUAT` int(11) DEFAULT '0',
  `TONCUOI` int(11) NOT NULL,
  PRIMARY KEY (`STT`,`ID`),
  KEY `STT` (`STT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`tonkho`utf8_unicode_ci	;
INSERT INTO `tonkho` VALUES 
(1,1,'MAHDN00001','MH00001','2012-12-21 00:00:00',100,9,0,109),
(2,1,'MAHDX00014','MH00001','2012-12-21 00:00:00',109,0,6,103),
(2,2,'MAHDX00014','MH00002','2012-12-21 00:00:00',100,0,6,94),
(2,3,'MAHDX00014','MH00003','2012-12-21 00:00:00',100,0,6,94),
(3,1,'MATHDN00008','MH00001','2012-12-21 00:00:00',103,0,1,102),
(3,2,'MATHDN00008','MH00002','2012-12-21 00:00:00',94,0,1,93),
(3,3,'MATHDN00008','MH00003','2012-12-21 00:00:00',94,0,1,93),
(4,1,'MATHDX00008','MH00001','2012-12-21 00:00:00',102,2,0,104),
(4,2,'MATHDX00008','MH00002','2012-12-21 00:00:00',93,3,0,96),
(4,3,'MATHDX00008','MH00003','2012-12-21 00:00:00',93,2,0,95),
(5,1,'MAHDN00002','MH00001','2012-12-21 00:00:00',104,3,0,107),
(5,2,'MAHDN00002','MH00003','2012-12-21 00:00:00',95,3,0,98),
(5,3,'MAHDN00002','MH00002','2012-12-21 00:00:00',96,3,0,99),
(6,1,'MAHDX00015','MH00001','2012-12-21 00:00:00',107,0,3,104),
(6,2,'MAHDX00015','MH00002','2012-12-21 00:00:00',99,0,2,97),
(6,3,'MAHDX00015','MH00003','2012-12-21 00:00:00',98,0,2,96),
(6,4,'MAHDX00015','MH00001','2012-12-21 00:00:00',104,0,1,103),
(7,1,'MATHDN00009','MH00001','2012-12-21 00:00:00',103,0,1,102),
(7,2,'MATHDN00009','MH00002','2012-12-21 00:00:00',97,0,1,96),
(7,3,'MATHDN00009','MH00003','2012-12-21 00:00:00',96,0,1,95),
(8,1,'MATHDX00009','MH00001','2012-12-21 00:00:00',102,2,0,104),
(8,2,'MATHDX00009','MH00002','2012-12-21 00:00:00',96,2,0,98),
(8,3,'MATHDX00009','MH00003','2012-12-21 00:00:00',95,2,0,97),
(9,1,'MAHDN00003','MH00001','2012-12-22 00:00:00',104,5,0,109),
(10,1,'MAHDX00016','MH00001','2012-12-22 00:00:00',109,0,2,107),
(11,1,'MATHDN00010','MH00001','2012-12-22 00:00:00',107,0,2,105),
(12,1,'MATHDX00010','MH00001','2012-12-22 00:00:00',105,2,0,107),
(13,1,'MAHDN00004','MH00001','2012-12-23 00:00:00',107,2,0,109),
(14,1,'MAHDX00017','MH00001','2012-12-23 00:00:00',109,0,1,108),
(15,1,'MATHDN00011','MH00001','2012-12-23 00:00:00',108,0,1,107),
(16,1,'MATHDX00011','MH00001','2012-12-23 00:00:00',107,2,0,109),
(17,1,'MAHDN00005','MH00001','2012-12-25 00:00:00',109,5,0,114),
(18,1,'MAHDX00018','MH00001','2012-12-25 00:00:00',114,0,2,112),
(19,1,'MATHDN00012','MH00001','2012-12-25 00:00:00',112,0,1,111),
(20,1,'MATHDX00012','MH00001','2012-12-25 00:00:00',111,2,0,113),
(21,1,'MAHDN00006','MH00001','2012-12-25 00:00:00',113,2,0,115),
(22,1,'MAHDX00019','MH00001','2012-12-25 00:00:00',115,0,3,112),
(23,1,'MATHDN00013','MH00001','2012-12-25 00:00:00',112,0,1,111),
(24,1,'MATHDX00013','MH00001','2012-12-25 00:00:00',111,2,0,113),
(25,1,'MAHDN00007','MH00001','2012-12-25 00:00:00',113,3,0,116),
(25,2,'MAHDN00007','MH00003','2012-12-25 00:00:00',97,3,0,100),
(25,3,'MAHDN00007','MH00002','2012-12-25 00:00:00',98,3,0,101),
(26,1,'MAHDX00020','MH00001','2012-12-25 00:00:00',116,0,2,114),
(26,2,'MAHDX00020','MH00002','2012-12-25 00:00:00',101,0,2,99),
(27,1,'MATHDN00014','MH00001','2012-12-25 00:00:00',114,0,1,113),
(27,2,'MATHDN00014','MH00002','2012-12-25 00:00:00',99,0,2,97),
(28,1,'MATHDX00014','MH00001','2012-12-25 00:00:00',113,2,0,115),
(28,2,'MATHDX00014','MH00002','2012-12-25 00:00:00',97,2,0,99),
(28,3,'MATHDX00014','MH00003','2012-12-25 00:00:00',100,2,0,102),
(28,4,'MATHDX00014','MH00002','2012-12-25 00:00:00',97,2,0,99),
(29,1,'MAHDX00021','MH00004','2012-12-26 00:00:00',115,0,2,113),
(30,1,'MAHDN00008','MH00001','2012-12-29 00:00:00',113,0,0,113),
(31,1,'MAHDX00022','MH00002','2012-12-29 00:00:00',99,0,0,99)	;
#	TC`trachitiethdn`utf8_unicode_ci	;
CREATE TABLE `trachitiethdn` (
  `ID` int(11) NOT NULL,
  `MAHDN` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MAMH` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `SOLUONGNHAP` int(11) DEFAULT NULL,
  `GIANHAP` bigint(20) DEFAULT NULL,
  `TINHTRANG` bit(1) DEFAULT NULL,
  PRIMARY KEY (`ID`,`MAHDN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`trachitiethdn`utf8_unicode_ci	;
INSERT INTO `trachitiethdn` VALUES 
(1,'MATHDN00008','MH00001',1,99,'1'),
(1,'MATHDN00009','MH00001',1,99,'1'),
(1,'MATHDN00010','MH00001',2,99,'1'),
(1,'MATHDN00011','MH00001',1,99,'1'),
(1,'MATHDN00012','MH00001',1,99,'1'),
(1,'MATHDN00013','MH00001',1,99,'1'),
(1,'MATHDN00014','MH00001',1,99,'1'),
(2,'MATHDN00008','MH00002',1,99,'1'),
(2,'MATHDN00009','MH00002',1,99,'1'),
(2,'MATHDN00014','MH00002',2,99,'1'),
(3,'MATHDN00008','MH00003',1,89,'1'),
(3,'MATHDN00009','MH00003',1,89,'1')	;
#	TC`trachitiethdx`utf8_unicode_ci	;
CREATE TABLE `trachitiethdx` (
  `ID` int(11) NOT NULL,
  `MAHDX` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MAMH` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `SOLUONGXUAT` int(11) DEFAULT NULL,
  `GIATIEN` bigint(20) DEFAULT NULL,
  `TINHTRANG` bit(1) DEFAULT NULL,
  PRIMARY KEY (`ID`,`MAHDX`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`trachitiethdx`utf8_unicode_ci	;
INSERT INTO `trachitiethdx` VALUES 
(1,'MATHDX00008','MH00001',2,99,'1'),
(1,'MATHDX00009','MH00001',2,99,'1'),
(1,'MATHDX00010','MH00001',2,99,'1'),
(1,'MATHDX00011','MH00001',2,99,'1'),
(1,'MATHDX00012','MH00001',2,99,'1'),
(1,'MATHDX00013','MH00001',2,99,'1'),
(1,'MATHDX00014','MH00001',2,99,'1'),
(2,'MATHDX00008','MH00002',3,99,'1'),
(2,'MATHDX00009','MH00002',2,99,'1'),
(2,'MATHDX00014','MH00002',2,99,'1'),
(3,'MATHDX00008','MH00003',2,89,'1'),
(3,'MATHDX00009','MH00003',2,89,'1'),
(3,'MATHDX00014','MH00003',2,89,'1')	;
#	TC`trahoadonnhap`utf8_unicode_ci	;
CREATE TABLE `trahoadonnhap` (
  `MAHDN` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MANCC` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MANV` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MAKHO` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `NGAYNHAP` datetime DEFAULT NULL,
  `TIENPHAITRA` bigint(20) DEFAULT NULL,
  `TIENDATRA` bigint(20) DEFAULT NULL,
  `GHICHU` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TINHTRANG` bit(1) DEFAULT NULL,
  PRIMARY KEY (`MAHDN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`trahoadonnhap`utf8_unicode_ci	;
INSERT INTO `trahoadonnhap` VALUES 
('MATHDN00008','MANCC00001','MANV00001','MAKHO00001','2012-12-21 00:00:00',287,0,'','1'),
('MATHDN00009','MANCC00001','MANV00001','MAKHO00001','2012-12-21 00:00:00',287,0,'','1'),
('MATHDN00010','MANCC00001','MANV00001','MAKHO00001','2012-12-22 00:00:00',198,0,'','1'),
('MATHDN00011','MANCC00001','MANV00001','MAKHO00001','2012-12-23 00:00:00',99,0,'','1'),
('MATHDN00012','MANCC00001','MANV00001','MAKHO00001','2012-12-25 00:00:00',99,0,'','1'),
('MATHDN00013','MANCC00001','MANV00001','MAKHO00001','2012-12-25 00:00:00',99,0,'ghi chú','1'),
('MATHDN00014','MANCC00001','MANV00001','MAKHO00001','2012-12-25 00:00:00',297,0,'','1')	;
#	TC`trahoadonxuat`utf8_unicode_ci	;
CREATE TABLE `trahoadonxuat` (
  `MAHDX` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MAKH` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MANV` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `MAKHO` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `NGAYXUAT` datetime DEFAULT NULL,
  `TIENPHAITRA` bigint(20) DEFAULT NULL,
  `TIENDATRA` bigint(20) DEFAULT NULL,
  `GHICHU` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TINHTRANG` bit(1) DEFAULT NULL,
  PRIMARY KEY (`MAHDX`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`trahoadonxuat`utf8_unicode_ci	;
INSERT INTO `trahoadonxuat` VALUES 
('MATHDX00008','KH00001','MANV00001','MAKHO00001','2012-12-21 00:00:00',673,0,'','1'),
('MATHDX00009','KH00001','MANV00001','MAKHO00001','2012-12-21 00:00:00',574,0,'','1'),
('MATHDX00010','KH00001','MANV00001','MAKHO00001','2012-12-22 00:00:00',198,0,'','1'),
('MATHDX00011','KH00001','MANV00001','MAKHO00001','2012-12-23 00:00:00',198,0,'','1'),
('MATHDX00012','KH00001','MANV00001','MAKHO00001','2012-12-25 00:00:00',198,0,'','1'),
('MATHDX00013','KH00001','MANV00001','MAKHO00001','2012-12-25 00:00:00',198,0,'ghi chú','1'),
('MATHDX00014','KH00001','MANV00001','MAKHO00001','2012-12-25 00:00:00',574,0,'','1')	;
#	PR`myProc`utf8_general_ci	;
CREATE PROCEDURE `myProc`()
BEGIN
    select * from tonkho;
END	;
